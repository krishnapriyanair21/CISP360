// TODO (1): includes / namespace declaration

const string BFF = "BFF";
const string IDK = "IDK";
const string JK = "JK";
const string TMI = "TMI";
const string TTYL = "TTYL";

const string BFF_LONG = "best friend forever";
const string IDK_LONG = "I don't know";
const string JK_LONG = "just kidding";
const string TMI_LONG = "too much information";
const string TTYL_LONG = " talk to you later";

int main() 
{
   //TODO (2):  declare a string to hold the sentence

   //TODO (3):  prompt the user input "Enter text:"
   
   //TODO (4):  declare a variable to hold a search index
   
   //TODO (5):  implement a find and replace while loop for each abbreviation (5 total)
   
   //TODO (6):  use a for loop to iterate through each character of the string and replace any '.' with '!'
   
   //TODO (6):  output the modified string

   return 0;
}