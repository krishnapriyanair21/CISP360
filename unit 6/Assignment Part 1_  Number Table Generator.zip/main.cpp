// TODO (1): Includes and namespace

// TODO (2): Define useful constants (widths, file name)

// In the main() function ...

    // TODO (3): Declare local variables

    // TODO (4): Acquire start, stop, and step values from user (validated, use a while loop while numbers are not valid)

    // TODO (5): Open output file for write (check-for / handle error)

    // TODO (6): Write table header to file

    // TODO (7): Construct `for` loop. For each iteration...

        // TODO (8): Write a row of the table to the file

    // TODO (9): Finish off the table with a dashed line

    // TODO (10): Close the file and write a message to `cout`

    // (Don't forget to return 0 at the end of the main function)
