// TODO (1): Includes and namespace

// TODO (2): Declare useful contents (file name template, widths, min and max table size)

// Inside main() function...

  // TODO (3): Declare local variables

  // TODO (4): Obtain (validated with a while loop) table size from user

  // TODO (5): Generate the filename

  // TODO (6): Open output file for write (abort, if an error occurs)

  // TODO (7): Write table column headers

  // TODO (8): Use nested `for` loops to write the main table
  // outer loop iterates over the rows
    // inner loop iterates over the columns

  // TODO (9): finish off with a final line, and close the file

  