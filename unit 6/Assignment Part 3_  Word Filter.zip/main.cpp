// TODO (1): includes and namespace declaration

// main() function:

    // TODO (2): declare local variables

    // TODO (3): acquire input filename (validated)

    // TODO (4): open input file (abort if failure)

    // TODO (5): generate output file names and open output files
    //           (check there were no errors, abort if failure)

    // TODO (6): initialize word counts

    // TODO (7): use a `while` loop to read in / test / output each word

    // TODO (8): close all files

    // TODO (9): output summary

    // (and what do we finish main() with?)
