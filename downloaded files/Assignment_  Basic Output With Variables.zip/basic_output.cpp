#include <iostream>
using namespace std;

int main() {
   int userNum = 0;

   cout << "Enter integer:" << endl;
   cin  >> userNum;

   /* Type your code here */

   return 0;
}
