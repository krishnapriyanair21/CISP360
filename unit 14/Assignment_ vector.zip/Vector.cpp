#include "Vector.h"

namespace Vector
{
   ///Define member functions here
   
}