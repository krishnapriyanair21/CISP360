#include "Vector.h"
using namespace Vector;

int main()
{
    return 0;
}

