#ifndef _STRING_H_INCLUDED
#define _STRING_H_INCLUDED

#define  strlen _strlen
#define  strcmp _strcmp
#define  strcpy _strcpy
#define  strncpy _strncpy
#define  strcat _strcat
#define  strncat _strncat
#define  strchr _strchr
#define  strrchr _strrchr
#define  strstr _strstr
#define  isalnum _isalnum

#endif // _STRING_H_INCLUDED
